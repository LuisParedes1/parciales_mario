package ar.fi.uba.modeloNuevo.Clases.Maderas;

public interface Madera {
    public int getGastoTotal(int metrosCuadrados);

    int getKg();
}
