package ar.fi.uba.modeloNuevo.Clases.Excepciones;

public class DatosInvalidos extends RuntimeException {
}
