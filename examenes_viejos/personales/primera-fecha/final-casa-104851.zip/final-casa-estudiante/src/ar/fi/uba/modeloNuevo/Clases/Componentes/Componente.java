package ar.fi.uba.modeloNuevo.Clases.Componentes;

public interface Componente {
    public int getGastoTotal();
}
