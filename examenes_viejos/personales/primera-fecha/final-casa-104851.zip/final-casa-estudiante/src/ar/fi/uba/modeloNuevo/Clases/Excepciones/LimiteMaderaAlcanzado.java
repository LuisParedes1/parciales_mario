package ar.fi.uba.modeloNuevo.Clases.Excepciones;

public class LimiteMaderaAlcanzado extends RuntimeException {
}
